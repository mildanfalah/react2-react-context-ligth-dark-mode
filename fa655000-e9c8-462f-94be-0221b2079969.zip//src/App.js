import React from 'react';

class App extends React.Component {
  render() {
    return (
      <div className="container">
        <p>Hello, World</p>
      </div>
    );
  }
}

export default App;
